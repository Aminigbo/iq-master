(function ($) {

    $(document).ready(function(){
         $('div, img').slideShow({
            timeOut: 2000,
            showNavigation: true,
            pauseOnHover: true,
            swipeNavigation: true
        });

        var navbar=$('.navbar')

        navbar.animate({top: '-100px'}, function () {
            navbar.hide();
        });
    })


    $('#activate').on('click', function () {
       

    })
}(jQuery));